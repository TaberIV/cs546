module.exports = {
	recipes: require("./recipes")
}